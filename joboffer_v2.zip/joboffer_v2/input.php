<?php
readfile('php://input');